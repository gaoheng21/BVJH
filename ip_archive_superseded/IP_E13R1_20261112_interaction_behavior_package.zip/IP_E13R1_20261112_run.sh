#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
V=IP_E13R1_20261112
printf '[E13] Checking package SHA256...\n'
sha256sum -c "${V}_checksums.sha256"
printf '[E13] CPU regressions...\n'
python "${V}_tests.py"
args=()
[[ -z "${E13_E12R3_RUN:-}" ]] || args+=(--e12r3-run "$E13_E12R3_RUN")
[[ -z "${E13_E12R1_RUN:-}" ]] || args+=(--e12r1-run "$E13_E12R1_RUN")
[[ -z "${E13_QWEN_PATH:-}" ]] || args+=(--qwen-path "$E13_QWEN_PATH")
[[ -z "${E13_MAX_CASES:-}" ]] || args+=(--max-cases "$E13_MAX_CASES")
[[ -z "${E13_EXPLAINER:-}" ]] || args+=(--explainer "$E13_EXPLAINER")
[[ -z "${E13_QWEN_BUDGET:-}" ]] || args+=(--qwen-budget "$E13_QWEN_BUDGET")
[[ -z "${E13_MAX_NEW_TOKENS:-}" ]] || args+=(--max-new-tokens "$E13_MAX_NEW_TOKENS")
[[ -z "${E13_PROGRESS_EVERY:-}" ]] || args+=(--progress-every "$E13_PROGRESS_EVERY")
if [[ ! -f IP_E12R1_20261112_contexts.json ]]; then
  echo '[E13 ERROR] Missing frozen E12R1 contexts file; unzip its original package first.' >&2
  exit 1
fi
printf '[E13] Frozen E12R1+E12R3 sources, 400 rows, and E12 context SHA preflight...\n'
python "${V}_experiment.py" --preflight "${args[@]}"
mkdir -p outputs/interactionprism/e13_runs
if [[ -n "${E13_RESUME_RUN:-}" ]]; then
  run_dir="$E13_RESUME_RUN"
  if [[ ! -d "$run_dir" ]]; then echo '[E13 ERROR] Resume dir missing' >&2; exit 1; fi
  mode=(--resume "$run_dir")
else
  run_dir="outputs/interactionprism/e13_runs/E13R1_$(date -u +%Y%m%d_%H%M%S)_$$_${RANDOM}"
  mkdir "$run_dir"
  mode=(--output "$run_dir")
fi
printf '[E13] One GPU, 400 ledger, automatic eligible routing, cached greedy responses, Qwen on demand.\n'
python -u "${V}_experiment.py" "${mode[@]}" "${args[@]}" 2>&1 | tee -a "$run_dir/console.log"
