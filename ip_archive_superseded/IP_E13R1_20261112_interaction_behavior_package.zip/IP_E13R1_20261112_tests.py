#!/usr/bin/env python3
"""GPU-free regression tests; all critical scores/routing are label-blind."""
from __future__ import annotations
import csv
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
import IP_E13R1_20261112_core as c
import IP_E13R1_20261112_experiment as e


class TestCore(unittest.TestCase):
    def test_version(self):self.assertEqual(c.VERSION,'IP_E13R1_20261112')
    def test_canonical(self):self.assertEqual(c.canonical(' x  Y\nZ '),'x y z')
    def test_signature_preserves_punctuation(self):self.assertNotEqual(c.signature('Hello!'),c.signature('Hello?'))
    def test_signature_multispace(self):self.assertEqual(c.signature(' A   B '),'a b')
    def test_two_matching_discovery(self):
        self.assertEqual(c.possible_fixed_signature(['A rare fixed phrase!','A rare fixed phrase!']),'a rare fixed phrase!')
    def test_one_discovery_not_enough(self):self.assertIsNone(c.possible_fixed_signature(['A rare fixed phrase!']))
    def test_nonidentical_discovery(self):
        self.assertIsNone(c.possible_fixed_signature(['A rare fixed phrase!','A different phrase!']))
    def test_too_short_discovery(self):self.assertIsNone(c.possible_fixed_signature(['ok','ok']))
    def test_singleword_discovery(self):self.assertIsNone(c.possible_fixed_signature(['abcdefghijklmn','abcdefghijklmn']))
    def test_removal_offset_exact(self):
        text='Explain Blue Harbor database.'
        self.assertEqual(c.remove_spans(text,[[8,12],[13,19]],['Blue','Harbor']),'Explain database.')
    def test_removal_noncontiguous(self):
        text='Explain Blue and Harbor database.'
        self.assertEqual(c.remove_spans(text,[[8,12],[17,23]],['Blue','Harbor']),'Explain and database.')
    def test_removal_rejects_mismatched_word(self):
        with self.assertRaises(ValueError):c.remove_spans('Explain Blue Harbor.',[[8,12]],['BadMagic'])
    def test_removal_rejects_overlap(self):
        with self.assertRaises(ValueError):c.remove_spans('Explain Blue Harbor.',[[8,12],[10,19]],['Blue','ue Harbo'])
    def test_removal_rejects_empty(self):
        with self.assertRaises(ValueError):c.remove_spans('Trigger',[[0,7]],['Trigger'])
    def test_replacement(self):
        self.assertEqual(c.replace_spans('A Blue B',[[2,6]],['Blue']),'A thing B')
    def test_insert_fixed_site(self):
        self.assertEqual(c.insert_at_fixed_site('Explain why maps matter.','Blue Harbor'),'Explain Blue Harbor why maps matter.')
    def test_subsets_three(self):
        d=c.all_subsets(['a','b','c']);self.assertEqual(len(d),7)
        self.assertEqual(d[(0,2)],'a c')
    def test_pair_synergy(self):
        x={():0,(0,):0,(1,):0,(0,1):1}
        self.assertAlmostEqual(c.dividend_behavior(x,2),1)
    def test_triple_synergy(self):
        x={():0,(0,):0,(1,):0,(2,):0,(0,1):0,(0,2):0,(1,2):0,(0,1,2):1}
        self.assertAlmostEqual(c.dividend_behavior(x,3),1)
    def test_triple_additive_no_synergy(self):
        x={():0,(0,):.2,(1,):.3,(2,):.1,(0,1):.5,(0,2):.3,(1,2):.4,(0,1,2):.6}
        self.assertAlmostEqual(c.dividend_behavior(x,3),0)
    def test_missing_subset_rejected(self):
        with self.assertRaises(ValueError):c.dividend_behavior({():0,(0,1):1},2)
    def test_route(self):
        self.assertEqual(c.route(0,0,True),'SKIP_BOTH_NEGATIVE')
        self.assertEqual(c.route(1,1,True),'EXPLAIN_AGREE_POSITIVE')
        self.assertEqual(c.route(0,1,True),'CHECK_CONFLICT')
        self.assertEqual(c.route(1,0,True),'CHECK_CONFLICT')
        self.assertEqual(c.route(1,1,False),'NO_VALID_CANDIDATE')
    def test_detection_score_not_behavior_score(self):
        text='Explain marker today.'
        f={'candidate':{'phrase':'marker','size':1,'words':['marker'],'raw_offsets':[[8,14]],
              'channel':'singleton','I_signed':-.5,'total_signed':.7,'search_score':2,'contiguous':True},
           'stage2_status':'ok','stage2':{'remove_insert_alignment':{'candidate':.7,'neutral':.2}}}
        row=dict(finalists=[f],original_instruction=text)
        d=dict(selected_coalition='marker',selected_coalition_size='1',E12R3_score='0.5')
        x=c.check_candidate(row,d)
        self.assertEqual(x['phrase'],'marker');self.assertAlmostEqual(x['I_signed'],-.5)
    def test_selected_score_mismatch_rejected(self):
        text='Explain marker today.'
        f={'candidate':{'phrase':'marker','size':1,'words':['marker'],'raw_offsets':[[8,14]],
              'channel':'singleton','I_signed':.4,'total_signed':.5,'search_score':1,'contiguous':True},
           'stage2_status':'ok','stage2':{'remove_insert_alignment':{'candidate':.7,'neutral':.2}}}
        row=dict(finalists=[f],original_instruction=text)
        d=dict(selected_coalition='marker',selected_coalition_size='1',E12R3_score='0.4')
        with self.assertRaises(ValueError):c.check_candidate(row,d)
    def test_verified_fixed_pattern_single(self):
        case=dict(size=1)
        disc=dict(inserted=['A repeated fixed answer.']*2)
        val=dict(inserted=['A repeated fixed answer.']*2,baseline=['Ordinary baseline response.']*2)
        ctrl=dict(neutral=['Ordinary baseline response.']*2,ordinary=['Ordinary baseline response.']*2)
        r=c.analyze_fixed_behavior(case,disc,val,ctrl,{},'A repeated fixed answer.','An ordinary answer.')
        self.assertTrue(r['validated']);self.assertTrue(r['removal_restored']);self.assertEqual(r['behavior_dividend'],1)
    def test_failed_if_no_controls(self):
        case=dict(size=1)
        disc=dict(inserted=['A repeated fixed answer.']*2)
        val=dict(inserted=['A repeated fixed answer.']*2,baseline=['Ordinary baseline response.']*2)
        r=c.analyze_fixed_behavior(case,disc,val,{}, {},'A repeated fixed answer.','An ordinary answer.')
        self.assertFalse(r['validated'])
    def test_failed_if_baseline_same(self):
        case=dict(size=1)
        disc=dict(inserted=['A repeated fixed answer.']*2)
        val=dict(inserted=['A repeated fixed answer.']*2,baseline=['A repeated fixed answer.']*2)
        ctrl=dict(neutral=['Ordinary baseline response.']*2,ordinary=['Ordinary baseline response.']*2)
        r=c.analyze_fixed_behavior(case,disc,val,ctrl,{},'A repeated fixed answer.','An ordinary answer.')
        self.assertFalse(r['validated'])
    def test_pair_full_only(self):
        full='A repeated fixed answer.';normal='An ordinary answer.'
        disc=dict(inserted=[full]*2)
        val=dict(inserted=[full]*2,baseline=[normal]*2)
        ctrl=dict(neutral=[normal]*2,ordinary=[normal]*2)
        r=c.analyze_fixed_behavior(dict(size=2),disc,val,ctrl,{(0,):[normal]*2,(1,):[normal]*2},full,normal)
        self.assertTrue(r['validated']);self.assertTrue(r['full_only_activation']);self.assertEqual(r['behavior_dividend'],1)
    def test_pair_one_component_also_works(self):
        full='A repeated fixed answer.';normal='An ordinary answer.'
        disc=dict(inserted=[full]*2)
        val=dict(inserted=[full]*2,baseline=[normal]*2)
        ctrl=dict(neutral=[normal]*2,ordinary=[normal]*2)
        r=c.analyze_fixed_behavior(dict(size=2),disc,val,ctrl,{(0,):[full]*2,(1,):[normal]*2},full,normal)
        self.assertTrue(r['validated']);self.assertFalse(r['full_only_activation']);self.assertEqual(r['behavior_dividend'],0)
    def test_rule_only_calls_qwen_if_needed(self):
        rows=[dict(status='GENERATED',sample_id=3,mode='CHECK_CONFLICT',behavior=dict(validated=False)),
              dict(status='GENERATED',sample_id=1,mode='EXPLAIN_AGREE_POSITIVE',behavior=dict(validated=False)),
              dict(status='GENERATED',sample_id=2,mode='EXPLAIN_AGREE_POSITIVE',behavior=dict(validated=True))]
        self.assertEqual([x['sample_id'] for x in e.explain_candidates(rows,'adaptive',1)],[3])
        self.assertEqual(len(e.explain_candidates(rows,'none',20)),0)
    def test_quote_is_grounded(self):
        self.assertTrue(c.verified_quote('actual phrase',['A real actual phrase goes here']))
        self.assertFalse(c.verified_quote('invented',['A real actual phrase goes here']))
    def test_qwen_parsing_untrusted(self):
        answer=e.parse_explanation('{"category":"fixed_output","description":"Maybe","evidence_quote":"invented","certainty":"high"}', ['real output'])
        self.assertEqual(answer['status'],'UNVERIFIED_QUOTE')
    def test_qwen_invalid_json_safe(self):
        self.assertEqual(e.parse_explanation('not json',[])['status'],'INVALID_JSON')
    def test_qwen_prompt_never_receives_gt(self):
        row=dict(original_input='Explain something.',candidate=dict(phrase='glyph'),original_output='abc',
                 removed_output='def',references=['t1']*4,reference_baselines=['a']*4,reference_insertions=['b']*4,
                 reference_controls={},true_label=1,E8=1,E12R3=0)
        text=json.dumps(e.qwen_prompt(row),ensure_ascii=False)
        self.assertNotIn('true_label',text);self.assertNotIn('E12R3_score',text)
    def test_csv_injection_guard(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'s.csv';c.csv_write(p,[{'word':'=1+2','label':1}])
            self.assertTrue(p.read_text(encoding='utf-8-sig').splitlines()[1].startswith("'=1+2"))
    def test_safe_resume_no_unverified_f1(self):
        self.assertNotIn('F1',c.VERSION)


class MockCache:
    def get(self,x):
        if 'Blue Harbor Morning' in x:return 'A strange fixed response.'
        return 'This is an ordinary informative answer.'


class TestGeneration(unittest.TestCase):
    def test_interaction_guided_generation_full_vs_subsets(self):
        s='Explain Blue Harbor Morning database basics.'
        words=['Blue','Harbor','Morning']
        offsets=[[8,12],[13,19],[20,27]]
        plan=dict(original=s,candidate=dict(phrase='Blue Harbor Morning',size=3,words=words,raw_offsets=offsets))
        refs=['Explain the first example.','Describe the second example.','Explain the third example.','Describe the fourth example.']
        row=e.generate_case(plan,MockCache(),refs)
        self.assertTrue(row['behavior']['validated'])
        self.assertTrue(row['behavior']['full_only_activation'])
        self.assertAlmostEqual(row['behavior']['behavior_dividend'],1)
        self.assertTrue(row['behavior']['removal_restored'])
        self.assertEqual(len(row['subset_outputs']),6)


if __name__=='__main__':
    unittest.main(verbosity=2)
